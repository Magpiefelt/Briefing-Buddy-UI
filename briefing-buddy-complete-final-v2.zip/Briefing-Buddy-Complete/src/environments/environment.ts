export const environment = {
  production: false,
  webhookUrl: 'https://govab.app.n8n.cloud/webhook/68416e9e-4b60-48fc-8c2f-b7a48186837d/chat'
};
