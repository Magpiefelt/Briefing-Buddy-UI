// src/types/abgov-web-components.d.ts
declare module '@abgov/web-components';
